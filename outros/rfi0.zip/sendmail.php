<?php

    if (isset($_POST['submit'])){
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $mensaxe = $_POST['mensaxe'];
        $para = 'mciago.gz@hotmail.com';
        $titulo = $_POST['titulo'];
        $header = 'From: ' . $email;
        $msxCorreo = "Nome: $nome\n E-Mail: $email\n Mensaxe:\n $mensaxe";
        
        echo $para.'<br>';
        echo $titulo.'<br>';
        echo $msxCorreo.'<br>';
        echo $header.'<br>';
                
        if (mail($para, $titulo, $msxCorreo, $header)) {
            echo "<script language='javascript'>
            alert('Mensaxe enviada con exito');
            window.location.href = 'index.html';
            </script>";
        } else {
            echo "<script language='javascript'>
            alert('Non se puido enviar a mensaxe');
            window.location.href = 'index.html';
            </script>";
        }
    }
?>
