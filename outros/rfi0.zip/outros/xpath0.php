<!DOCTYPE html>
<html>
    <head>
        <title>XPATH</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        
        <link rel="stylesheet" href="../static/estilo.css" />
        <link rel="stylesheet" href="../static/bootstrap.css" />
        <link rel="stylesheet" href="../static/bootstrap-theme.css" />
    </head>
    <body>
        <form class="form-signin" id="retosForm" action="" method="GET" role="form">
            <input class="form-control" type="text" name="user" placeholder="User">
            <input class="form-control" type="password" name="pass" placeholder="Pass">
            <button class="btn btn-lg btn-primary btn-block" type="submit" name="login">Login</button>

<?php
error_reporting(E_ALL);
ini_set('display_errors', True);
$user = $_GET["user"];
$pass = $_GET["pass"];
$string = <<<XML
<users>
    <user>
        <username>admin</username>
        <password>abc123.</password>
    </user>
</users>
XML;
$xml = new SimpleXMLElement($string);
$resultado = $xml->xpath("//users/user[username/text()='" . $user . "' and password/text()='" . $pass . "']");
if($resultado){
    echo 'Correcto';
}else{
    echo 'Incorrecto';
}
?>
</form>
</body>
</html>
