<?php

system("uname -a");

?>
